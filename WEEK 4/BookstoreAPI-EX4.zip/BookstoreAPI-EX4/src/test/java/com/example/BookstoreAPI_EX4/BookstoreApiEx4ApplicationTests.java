package com.example.BookstoreAPI_EX4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
