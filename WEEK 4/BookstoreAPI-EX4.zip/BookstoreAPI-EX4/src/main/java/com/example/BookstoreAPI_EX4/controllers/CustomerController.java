package com.example.BookstoreAPI_EX4.controllers;

import com.example.BookstoreAPI_EX4.entity.Customer;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@SuppressWarnings("unused")
@RestController
@RequestMapping("/customers")
public class CustomerController {

    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        // Mock implementation, in real scenario save customer to DB
        customer.setId(1L); // assuming ID is auto-generated
        return customer;
    }

    @PostMapping("/register")
    public String registerCustomer(@RequestParam String name, @RequestParam String email, @RequestParam String address) {
        // Handle form data submission
        return String.format("Customer %s with email %s and address %s registered successfully.", name, email, address);
    }
}

