package com.example.BookstoreAPI__EX5.controllers;


import com.example.BookstoreAPI__EX5.entity.Customer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    // Endpoint to create a new customer with custom response status
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)  // Sets HTTP status to 201 Created
    public Customer createCustomer(@RequestBody Customer customer) {
        customer.setId(1L);  // In a real application, ID would be auto-generated
        return customer;
    }

    // Endpoint to register a customer with custom response headers
    @PostMapping("/register")
    public ResponseEntity<String> registerCustomer(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String address) {

        // Custom headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "BookstoreAPI");

        // Response body
        String body = String.format("Customer %s with email %s and address %s registered successfully.", name, email, address);

        // Return response with custom headers and status 200 OK
        return ResponseEntity.ok().headers(headers).body(body);
    }
}

