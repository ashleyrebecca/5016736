package com.example.BookstoreAPI_EX7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiEx7Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApiEx7Application.class, args);
	}

}
