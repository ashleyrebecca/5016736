package com.example.BookstoreAPI_EX7.controllers;

import com.example.BookstoreAPI_EX7.entity.Book;
import com.example.BookstoreAPI_EX7.exceptions.BookNotFoundException;
import com.example.BookstoreAPI_EX7.service.BookService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/books")
public class BookController {
    // Other methods

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        // Assume bookService.getBookById(id) is a method to fetch the book by ID
        Book book = BookService.getBookById(id);
        if (book == null) {
            throw new BookNotFoundException("Book not found with ID: " + id);
        }
        return new ResponseEntity<>(book, HttpStatus.OK);
    }
}

