package com.example.BookstoreAPI_EX3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
