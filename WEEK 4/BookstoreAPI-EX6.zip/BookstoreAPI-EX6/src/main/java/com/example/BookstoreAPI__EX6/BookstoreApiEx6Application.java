package com.example.BookstoreAPI__EX6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiEx6Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApiEx6Application.class, args);
	}

}
