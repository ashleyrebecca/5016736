package com.example.BookstoreAPI_EX2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
