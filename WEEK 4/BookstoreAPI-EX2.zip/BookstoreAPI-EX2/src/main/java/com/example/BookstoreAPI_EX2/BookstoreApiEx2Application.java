package com.example.BookstoreAPI_EX2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiEx2Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApiEx2Application.class, args);
	}

}
