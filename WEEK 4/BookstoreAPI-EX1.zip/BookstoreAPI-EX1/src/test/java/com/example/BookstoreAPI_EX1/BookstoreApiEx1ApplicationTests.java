package com.example.BookstoreAPI_EX1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
