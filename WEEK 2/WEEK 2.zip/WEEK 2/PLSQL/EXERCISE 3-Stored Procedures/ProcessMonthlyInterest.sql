SET SERVEROUTPUT ON;
CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS
BEGIN
    FOR rec IN (SELECT AccountID, Balance FROM Accounts WHERE AccountType = 'Savings') LOOP
        UPDATE Accounts
        SET Balance = Balance + (Balance * 0.01), LastModified = SYSDATE
        WHERE AccountID = rec.AccountID;
    END LOOP;
     ProcessMonthlyInterest;
    COMMIT;
END ProcessMonthlyInterest;
/
SELECT * FROM Accounts;

--OUTPUT
--ACCOUNTID CUSTOMERID ACCOUNTTYPE             BALANCE LASTMODI
---------- ---------- -------------------- ---------- --------
--       101          1 Savings                    8000 05-08-24
--       102          2 Savings                    7000 05-08-24
--       103          3 Savings                   15000 05-08-24

