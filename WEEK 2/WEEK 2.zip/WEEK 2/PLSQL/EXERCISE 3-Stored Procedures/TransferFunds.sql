SET SERVEROUTPUT ON;
CREATE OR REPLACE PROCEDURE TransferFunds (
    p_FromAccountID IN NUMBER,
    p_ToAccountID IN NUMBER,
    p_Amount IN NUMBER
) IS
    l_FromBalance NUMBER;
BEGIN
    -- Fetch balance of the source account
    SELECT Balance INTO l_FromBalance FROM Accounts WHERE AccountID = p_FromAccountID;
    
    -- Check sufficient funds
    IF l_FromBalance < p_Amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in the source account');
    END IF;

    -- Perform transfer
    UPDATE Accounts SET Balance = Balance - p_Amount, LastModified = SYSDATE WHERE AccountID = p_FromAccountID;
    UPDATE Accounts SET Balance = Balance + p_Amount, LastModified = SYSDATE WHERE AccountID = p_ToAccountID;
     TransferFunds(101, 102, 1000);
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END TransferFunds;
/

SELECT * FROM Accounts;

--OUTPUT

-- ACCOUNTID CUSTOMERID ACCOUNTTYPE             BALANCE LASTMODI
---------- ---------- -------------------- ---------- --------
--       101          1 Savings                    8000 05-08-24
--       102          2 Savings                    7000 05-08-24
--       103          3 Savings                   15000 05-08-24
