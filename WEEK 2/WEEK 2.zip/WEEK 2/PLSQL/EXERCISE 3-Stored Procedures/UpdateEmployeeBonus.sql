SET SERVEROUTPUT ON;
CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (
    p_Department IN VARCHAR2,
    p_BonusPercentage IN NUMBER
) IS
BEGIN
    UPDATE Employees
    SET Salary = Salary + (Salary * p_BonusPercentage / 100)
    WHERE Department = p_Department;
     UpdateEmployeeBonus('Finance', 10);
    
    COMMIT;
END UpdateEmployeeBonus;
/
SELECT * FROM Employees;

--OUTPUT
--EMPLOYEEID NAME                                                                                                 POSITION                                               SALARY DEPARTMENT                                         HIREDATE
---------- ---------------------------------------------------------------------------------------------------- -------------------------------------------------- ---------- -------------------------------------------------- --------
--         1 John Doe                                                                                             Manager                                                 84700 Finance                                            05-08-24
--         2 Jane Smith                                                                                           Clerk                                                   50000 HR                                                 05-08-24
