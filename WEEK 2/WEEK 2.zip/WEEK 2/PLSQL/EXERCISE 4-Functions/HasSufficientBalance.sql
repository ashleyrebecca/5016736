SET SERVEROUTPUT ON;
CREATE OR REPLACE FUNCTION HasSufficientBalance (
    p_AccountID IN NUMBER,
    p_Amount IN NUMBER
) RETURN BOOLEAN IS
    l_Balance NUMBER;
BEGIN
    SELECT Balance INTO l_Balance
    FROM Accounts
    WHERE AccountID = p_AccountID;

    RETURN l_Balance >= p_Amount;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN FALSE;
END HasSufficientBalance;
/

