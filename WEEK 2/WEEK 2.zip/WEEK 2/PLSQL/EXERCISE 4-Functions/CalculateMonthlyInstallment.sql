SET SERVEROUTPUT ON;
CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment (
    p_LoanAmount IN NUMBER,
    p_AnnualInterestRate IN NUMBER,
    p_LoanDurationYears IN NUMBER
) RETURN NUMBER IS
    l_MonthlyInterestRate NUMBER;
    l_NumPayments NUMBER;
    l_MonthlyInstallment NUMBER;
BEGIN
    l_MonthlyInterestRate := (p_AnnualInterestRate / 12) / 100;
    l_NumPayments := p_LoanDurationYears * 12;

    IF l_MonthlyInterestRate > 0 THEN
        l_MonthlyInstallment := p_LoanAmount * 
            (l_MonthlyInterestRate * POWER(1 + l_MonthlyInterestRate, l_NumPayments)) / 
            (POWER(1 + l_MonthlyInterestRate, l_NumPayments) - 1);
    ELSE
        l_MonthlyInstallment := p_LoanAmount / l_NumPayments;
    END IF;

    RETURN l_MonthlyInstallment;
END CalculateMonthlyInstallment;
/
-- Calculate monthly installment for a loan amount of 10000, annual interest rate of 5%, and duration of 5 years
SELECT CalculateMonthlyInstallment(10000, 5, 5) AS MonthlyInstallment FROM dual;

--OUTPUT
--MONTHLYINSTALLMENT
------------------
--        188.712336

