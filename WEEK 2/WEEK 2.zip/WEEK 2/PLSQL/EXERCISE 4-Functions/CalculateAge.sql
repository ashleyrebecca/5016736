SET SERVEROUTPUT ON;
CREATE OR REPLACE FUNCTION CalculateAge (
    p_CustomerID IN NUMBER
) RETURN NUMBER IS
    l_Age NUMBER;
BEGIN
    SELECT Age INTO l_Age
    FROM Customers
    WHERE CustomerID = p_CustomerID;

    RETURN l_Age;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL; -- Handle cases where customer does not exist
END CalculateAge;
/
-- Fetch age for customer with ID 1
SELECT CalculateAge(1) AS Age FROM dual;

--OUTPUT
--      AGE
----------
--        65





