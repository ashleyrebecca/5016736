SET SERVEROUTPUT ON;
-- Hire a new employee
BEGIN
    EmployeeManagement.HireEmployee(4, 'Eva Green', 'Manager', 6000, 'Finance');
END;
/

-- Update employee details
BEGIN
    EmployeeManagement.UpdateEmployeeDetails(4, 'Eva Green', 'Senior Manager', 6500, 'Finance');
END;
/

-- Calculate annual salary
DECLARE
    v_AnnualSalary NUMBER;
BEGIN
    v_AnnualSalary := EmployeeManagement.CalculateAnnualSalary(4);
    DBMS_OUTPUT.PUT_LINE('Annual Salary: ' || v_AnnualSalary);
END;
/

--OUTPUT
--Annual Salary: 78000