SET SERVEROUTPUT ON;
-- Add a new customer
BEGIN
    CustomerManagement.AddCustomer(4, 'David', 55);
END;
/

-- Update customer details
BEGIN
    CustomerManagement.UpdateCustomerDetails(4, 'David', 56);
END;
/

-- Get customer balance
DECLARE
    v_Balance NUMBER;
BEGIN
    v_Balance := CustomerManagement.GetCustomerBalance(4);
    DBMS_OUTPUT.PUT_LINE('Customer Balance: ' || v_Balance);
END;
/

--OUTPUT
--Customer Balance: [calculated balance based on inserted data]


