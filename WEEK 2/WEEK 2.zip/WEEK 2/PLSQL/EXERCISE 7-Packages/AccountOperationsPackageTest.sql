SET SERVEROUTPUT ON;
-- Open a new account
BEGIN
    AccountOperations.OpenAccount(104, 4, 'Savings', 7000);
END;
/

-- Close an account
BEGIN
    AccountOperations.CloseAccount(104);
END;
/

-- Get total balance of a customer
DECLARE
    v_TotalBalance NUMBER;
BEGIN
    v_TotalBalance := AccountOperations.GetTotalBalance(4);
    DBMS_OUTPUT.PUT_LINE('Total Balance: ' || v_TotalBalance);
END;
/
--OUTPUT
--Total Balance: [total balance across all accounts for customer with ID 4]
