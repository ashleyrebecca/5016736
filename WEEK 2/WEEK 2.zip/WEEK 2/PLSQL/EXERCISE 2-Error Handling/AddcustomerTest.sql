SET SERVEROUTPUT ON;

BEGIN
    AddNewCustomer(4, 'David', 40, 6000);
    AddNewCustomer(1, 'Duplicate', 30, 3000); -- This should log an error because CustomerID 1 already exists
END;
/

SELECT * FROM Customers;

--OUTPUT
--Error: Customer ID already exists

--CUSTOMERID NAME                                                                                                        AGE    BALANCE I
---------- ---------------------------------------------------------------------------------------------------- ---------- ---------- -
--         1 Alice                                                                                                        65      15000 Y
--         2 Bob                                                                                                          45       8000 N
--         3 Charlie                                                                                                      70       5000 N
--         4 David                                                                                                        40       6000 N
