SET SERVEROUTPUT ON;

BEGIN
    SafeTransferFunds(101, 102, 1000);
END;
/

SELECT * FROM Accounts;
SELECT * FROM Transactions;

--OUTPUT
--ACCOUNTID CUSTOMERID ACCOUNTTYPE             BALANCE LASTMODI
---------- ---------- -------------------- ---------- --------
--       101          1 Savings                    8000 05-08-24
--     102          2 Savings                    7000 05-08-24


--TRANSACTIONID  ACCOUNTID TRANSACT     AMOUNT TRANSACTIO
------------- ---------- -------- ---------- ----------
--          1        101 05-08-24      -1000 Transfer  
--          2        102 05-08-24       1000 Transfer  
--          3        101 05-08-24      -1000 Transfer  
--          4        102 05-08-24       1000 Transfer  
