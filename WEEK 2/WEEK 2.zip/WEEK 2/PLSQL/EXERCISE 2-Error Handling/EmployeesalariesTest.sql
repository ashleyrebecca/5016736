SET SERVEROUTPUT ON;

BEGIN
    UpdateSalary(1, 10); -- Increase salary by 10%
    UpdateSalary(99, 10); -- This should log an error because EmployeeID 99 does not exist
END;
/

SELECT * FROM Employees;

--output
--Error: Employee ID not found
--EMPLOYEEID NAME                                                                                                 POSITION                                               SALARY DEPARTMENT                                         HIREDATE
---------- ---------------------------------------------------------------------------------------------------- -------------------------------------------------- ---------- -------------------------------------------------- --------
--        1 John Doe                                                                                             Manager                                                 77000 Finance                                            05-08-24
--        2 Jane Smith                                                                                           Clerk                                                   50000 HR                                                 05-08-24

