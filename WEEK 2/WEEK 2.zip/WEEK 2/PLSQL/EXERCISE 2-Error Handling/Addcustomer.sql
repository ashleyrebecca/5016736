CREATE OR REPLACE PROCEDURE AddNewCustomer (
    p_CustomerID IN NUMBER,
    p_Name IN VARCHAR2,
    p_Age IN NUMBER,
    p_Balance IN NUMBER
) AS
BEGIN
    -- Insert new customer
    INSERT INTO Customers (CustomerID, Name, Age, Balance, IsVIP)
    VALUES (p_CustomerID, p_Name, p_Age, p_Balance, 'N');

    COMMIT;
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Customer ID already exists');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END AddNewCustomer;

