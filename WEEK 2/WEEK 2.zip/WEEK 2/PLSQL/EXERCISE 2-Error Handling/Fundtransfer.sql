CREATE OR REPLACE PROCEDURE SafeTransferFunds (
    p_FromAccountID IN NUMBER,
    p_ToAccountID IN NUMBER,
    p_Amount IN NUMBER
) AS
    l_FromBalance NUMBER;
    l_ToBalance NUMBER;
BEGIN
    -- Fetch balances
    SELECT Balance INTO l_FromBalance FROM Accounts WHERE AccountID = p_FromAccountID;
    SELECT Balance INTO l_ToBalance FROM Accounts WHERE AccountID = p_ToAccountID;

    -- Check sufficient funds
    IF l_FromBalance < p_Amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in the source account');
    END IF;

    -- Perform transfer
    UPDATE Accounts SET Balance = Balance - p_Amount WHERE AccountID = p_FromAccountID;
    UPDATE Accounts SET Balance = Balance + p_Amount WHERE AccountID = p_ToAccountID;

    -- Log transaction
    INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
    VALUES (Transactions_seq.NEXTVAL, p_FromAccountID, SYSDATE, -p_Amount, 'Transfer');

    INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
    VALUES (Transactions_seq.NEXTVAL, p_ToAccountID, SYSDATE, p_Amount, 'Transfer');

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END SafeTransferFunds;



