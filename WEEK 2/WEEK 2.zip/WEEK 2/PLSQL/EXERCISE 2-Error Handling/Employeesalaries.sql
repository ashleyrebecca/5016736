CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_EmployeeID IN NUMBER,
    p_Percentage IN NUMBER
) AS
    l_Salary NUMBER;
BEGIN
    -- Fetch current salary
    SELECT Salary INTO l_Salary FROM Employees WHERE EmployeeID = p_EmployeeID;

    -- Update salary
    UPDATE Employees SET Salary = Salary + (Salary * p_Percentage / 100) WHERE EmployeeID = p_EmployeeID;

    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Error: Employee ID not found');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END UpdateSalary;

