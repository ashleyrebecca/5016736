CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
DECLARE
    l_Balance NUMBER;
BEGIN
    -- Check if the amount is positive for deposits
    IF :NEW.TransactionType = 'Deposit' AND :NEW.Amount <= 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Deposit amount must be positive.');
    END IF;

    -- Check if the balance is sufficient for withdrawals
    IF :NEW.TransactionType = 'Withdrawal' THEN
        SELECT Balance INTO l_Balance FROM Accounts WHERE AccountID = :NEW.AccountID;
        IF l_Balance < :NEW.Amount THEN
            RAISE_APPLICATION_ERROR(-20002, 'Insufficient balance for withdrawal.');
        END IF;
    END IF;
END;
