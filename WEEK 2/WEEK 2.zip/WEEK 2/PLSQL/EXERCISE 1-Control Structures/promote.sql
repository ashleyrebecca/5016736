DECLARE
    CURSOR cur_Customers IS SELECT * FROM Customers;
    v_Customer cur_Customers%ROWTYPE;
BEGIN
    FOR v_Customer IN cur_Customers LOOP
        IF v_Customer.Balance > 10000 THEN
            UPDATE Customers
            SET IsVIP = 'Y'
            WHERE CustomerID = v_Customer.CustomerID;
        END IF;
    END LOOP;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('VIP status updated for eligible customers.');
END;
/
--OUTPUT
--VIP status updated for eligible customers.
