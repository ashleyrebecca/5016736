DECLARE
    CURSOR cur_Loans IS SELECT Loans.LoanID, Customers.Name, Loans.DueDate
                        FROM Loans
                        JOIN Customers ON Loans.CustomerID = Customers.CustomerID
                        WHERE Loans.DueDate <= SYSDATE + 30;
    v_Loan cur_Loans%ROWTYPE;
BEGIN
    FOR v_Loan IN cur_Loans LOOP
        DBMS_OUTPUT.PUT_LINE('Reminder: Loan ID ' || v_Loan.LoanID || ' for customer ' || v_Loan.Name || ' is due on ' || v_Loan.DueDate);
    END LOOP;
END;
/

--OUTPUT
--Reminder: Loan ID 1 for customer Alice is due on 10-APR-24
--Reminder: Loan ID 3 for customer Charlie is due on 30-MAR-24