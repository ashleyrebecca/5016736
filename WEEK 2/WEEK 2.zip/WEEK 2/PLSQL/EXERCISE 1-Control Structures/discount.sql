DECLARE
    CURSOR cur_Customers IS SELECT * FROM Customers;
    v_Customer cur_Customers%ROWTYPE;
BEGIN
    FOR v_Customer IN cur_Customers LOOP
        IF v_Customer.Age > 60 THEN
            UPDATE Loans
            SET InterestRate = InterestRate - 1
            WHERE CustomerID = v_Customer.CustomerID;
        END IF;
    END LOOP;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Interest rates updated for customers above 60 years old.');
END;
/
--OUTPUT
--Interest rates updated for customers above 60 years old.
