-- Create Customers Table
CREATE TABLE Customers (
    CustomerID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    Age NUMBER,
    Balance NUMBER,
    IsVIP CHAR(1)
);

-- Create Loans Table
CREATE TABLE Loans (
    LoanID NUMBER PRIMARY KEY,
    CustomerID NUMBER,
    LoanAmount NUMBER,
    InterestRate NUMBER,
    DueDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Insert Sample Data into Customers Table
INSERT INTO Customers (CustomerID, Name, Age, Balance, IsVIP) VALUES (1, 'Alice', 65, 15000, 'N');
INSERT INTO Customers (CustomerID, Name, Age, Balance, IsVIP) VALUES (2, 'Bob', 45, 8000, 'N');
INSERT INTO Customers (CustomerID, Name, Age, Balance, IsVIP) VALUES (3, 'Charlie', 70, 5000, 'N');

-- Insert Sample Data into Loans Table
INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, DueDate) VALUES (1, 1, 10000, 5, SYSDATE + 20);
INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, DueDate) VALUES (2, 2, 20000, 6, SYSDATE + 40);
INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, DueDate) VALUES (3, 3, 15000, 4.5, SYSDATE + 10);

-- Creating Accounts table
CREATE TABLE Accounts (
    AccountID NUMBER PRIMARY KEY,
    CustomerID NUMBER,
    AccountType VARCHAR2(20),
    Balance NUMBER,
    LastModified DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Inserting data into Accounts table
INSERT INTO Accounts VALUES (101, 1, 'Savings', 10000, SYSDATE);
INSERT INTO Accounts VALUES (102, 2, 'Savings', 5000, SYSDATE);

-- Creating Transactions table
CREATE TABLE Transactions (
    TransactionID NUMBER PRIMARY KEY,
    AccountID NUMBER,
    TransactionDate DATE,
    Amount NUMBER,
    TransactionType VARCHAR2(10),
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID)
);

-- Creating Employees table
CREATE TABLE Employees (
    EmployeeID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    Position VARCHAR2(50),
    Salary NUMBER,
    Department VARCHAR2(50),
    HireDate DATE
);

-- Inserting data into Employees table
INSERT INTO Employees VALUES (1, 'John Doe', 'Manager', 70000, 'Finance', SYSDATE);
INSERT INTO Employees VALUES (2, 'Jane Smith', 'Clerk', 50000, 'HR', SYSDATE);