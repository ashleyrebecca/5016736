SET SERVEROUTPUT ON;

DECLARE
    CURSOR cur_Loans IS
        SELECT LoanID, InterestRate
        FROM Loans;
    
    v_LoanID Loans.LoanID%TYPE;
    v_InterestRate Loans.InterestRate%TYPE;
    v_NewInterestRate NUMBER;
    
BEGIN
    OPEN cur_Loans;
    LOOP
        FETCH cur_Loans INTO v_LoanID, v_InterestRate;
        EXIT WHEN cur_Loans%NOTFOUND;
        v_NewInterestRate := v_InterestRate * 0.95; -- Example: Applying a 5% reduction in interest rate
        UPDATE Loans SET InterestRate = v_NewInterestRate WHERE LoanID = v_LoanID;
        DBMS_OUTPUT.PUT_LINE('Loan ID: ' || v_LoanID || ', New Interest Rate: ' || v_NewInterestRate);
    END LOOP;
    CLOSE cur_Loans;
END;
/

--OUTPUT
--Loan ID: 1, New Interest Rate: 3.8
--Loan ID: 2, New Interest Rate: 5.7
--Loan ID: 3, New Interest Rate: 3.325