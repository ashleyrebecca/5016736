SET SERVEROUTPUT ON;

DECLARE
    CURSOR cur_Accounts IS
        SELECT AccountID, Balance
        FROM Accounts;
    
    v_AccountID Accounts.AccountID%TYPE;
    v_Balance Accounts.Balance%TYPE;
    v_AnnualFee CONSTANT NUMBER := 50; -- Annual fee amount
    
BEGIN
    OPEN cur_Accounts;
    LOOP
        FETCH cur_Accounts INTO v_AccountID, v_Balance;
        EXIT WHEN cur_Accounts%NOTFOUND;
        v_Balance := v_Balance - v_AnnualFee;
        UPDATE Accounts SET Balance = v_Balance WHERE AccountID = v_AccountID;
        DBMS_OUTPUT.PUT_LINE('Account ID: ' || v_AccountID || ', New Balance: ' || v_Balance);
    END LOOP;
    CLOSE cur_Accounts;
END;
/

--OUTPUT
--Account ID: 101, New Balance: 7950
--Account ID: 102, New Balance: 6950
--Account ID: 103, New Balance: 14950
