SET SERVEROUTPUT ON;

DECLARE
    CURSOR cur_Transactions IS
        SELECT c.Name, t.AccountID, t.TransactionDate, t.Amount, t.TransactionType
        FROM Transactions t
        JOIN Accounts a ON t.AccountID = a.AccountID
        JOIN Customers c ON a.CustomerID = c.CustomerID
        WHERE t.TransactionDate BETWEEN TRUNC(SYSDATE, 'MM') AND LAST_DAY(SYSDATE);
    
    v_Name Customers.Name%TYPE;
    v_AccountID Transactions.AccountID%TYPE;
    v_TransactionDate Transactions.TransactionDate%TYPE;
    v_Amount Transactions.Amount%TYPE;
    v_TransactionType Transactions.TransactionType%TYPE;
    
BEGIN
    OPEN cur_Transactions;
    LOOP
        FETCH cur_Transactions INTO v_Name, v_AccountID, v_TransactionDate, v_Amount, v_TransactionType;
        EXIT WHEN cur_Transactions%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('Customer: ' || v_Name || ', Account ID: ' || v_AccountID || 
                             ', Date: ' || TO_CHAR(v_TransactionDate, 'DD-MON-YYYY') || 
                             ', Amount: ' || v_Amount || ', Type: ' || v_TransactionType);
    END LOOP;
    CLOSE cur_Transactions;
END;
/
--OUTPUT
--Customer: Alice, Account ID: 101, Date: 05-AUG-2024, Amount: -1000, Type: Transfer
--Customer: Bob, Account ID: 102, Date: 05-AUG-2024, Amount: 1000, Type: Transfer
--Customer: Alice, Account ID: 101, Date: 05-AUG-2024, Amount: -1000, Type: Transfer
--Customer: Bob, Account ID: 102, Date: 05-AUG-2024, Amount: 1000, Type: Transfer



