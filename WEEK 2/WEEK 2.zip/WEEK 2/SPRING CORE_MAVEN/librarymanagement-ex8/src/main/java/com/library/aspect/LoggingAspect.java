package com.library.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    @Around("execution(* com.library.service.BookService.*(..))")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        
        // Proceed with the method execution
        Object proceed = joinPoint.proceed();
        
        long timeTaken = System.currentTimeMillis() - startTime;
        logger.info(joinPoint.getSignature() + " executed in " + timeTaken + "ms");
        
        return proceed;
    }
}

