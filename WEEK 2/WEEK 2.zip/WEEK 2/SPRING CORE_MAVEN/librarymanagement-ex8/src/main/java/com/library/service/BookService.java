package com.library.service;

import org.springframework.stereotype.Service;

@Service
public class BookService {

    public void listBooks() {
        // Simulate some processing
        System.out.println("Listing books...");
    }

    public void addBook(String book) {
        // Simulate adding a book
        System.out.println("Adding book: " + book);
    }
}

