package com.library;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.service.BookService;
import com.library.repository.BookRepository;

public class App {
    public static void main(String[] args) {
        @SuppressWarnings("resource")
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        BookService bookService = context.getBean(BookService.class);
        bookService.displayService();

        BookRepository bookRepository = context.getBean(BookRepository.class);
        bookRepository.displayRepository();
    }
}
/*OUTPUT
 * BookService is working.
BookRepository is working.
 */
