package com.library.controller;

import com.library.entity.Book;
import com.library.repository.BookRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private BookRepository bookRepository;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        bookRepository.deleteAll();
    }

    @Test
    public void shouldCreateBook() throws Exception {
        String newBook = "{\"title\": \"Spring Boot in Action\", \"author\": \"Craig Walls\"}";

        mockMvc.perform(post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(newBook))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Spring Boot in Action"))
                .andExpect(jsonPath("$.author").value("Craig Walls"));
    }

    @Test
    public void shouldGetAllBooks() throws Exception {
        Book book = new Book();
        book.setTitle("Spring Boot in Action");
        book.setAuthor("Craig Walls");
        bookRepository.save(book);

        mockMvc.perform(get("/books"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].title").value("Spring Boot in Action"))
                .andExpect(jsonPath("$[0].author").value("Craig Walls"));
    }

    @Test
    public void shouldGetBookById() throws Exception {
        Book book = new Book();
        book.setTitle("Spring Boot in Action");
        book.setAuthor("Craig Walls");
        Book savedBook = bookRepository.save(book);

        mockMvc.perform(get("/books/" + savedBook.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Spring Boot in Action"))
                .andExpect(jsonPath("$.author").value("Craig Walls"));
    }

    @Test
    public void shouldUpdateBook() throws Exception {
        Book book = new Book();
        book.setTitle("Spring Boot in Action");
        book.setAuthor("Craig Walls");
        Book savedBook = bookRepository.save(book);

        String updatedBook = "{\"title\": \"Spring Boot in Action - Updated\", \"author\": \"Craig Walls\"}";

        mockMvc.perform(put("/books/" + savedBook.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(updatedBook))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Spring Boot in Action - Updated"))
                .andExpect(jsonPath("$.author").value("Craig Walls"));
    }

    @Test
    public void shouldDeleteBook() throws Exception {
        Book book = new Book();
        book.setTitle("Spring Boot in Action");
        book.setAuthor("Craig Walls");
        Book savedBook = bookRepository.save(book);

        mockMvc.perform(delete("/books/" + savedBook.getId()))
                .andExpect(status().isOk());

        mockMvc.perform(get("/books/" + savedBook.getId()))
                .andExpect(status().isNotFound());
    }
}

