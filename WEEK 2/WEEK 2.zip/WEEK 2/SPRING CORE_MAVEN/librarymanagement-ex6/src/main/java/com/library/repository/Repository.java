package com.library.repository;

public @interface Repository {

}
