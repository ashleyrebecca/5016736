
public class LoggerTest {
    public static void main(String[] args) {
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();
        System.out.println("Both instances are the same!" );
        logger1.log("Hello");
        logger2.log("This is a test message.");
    }
}
