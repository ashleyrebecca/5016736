public class StrategyPatternTest {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext(new CreditCardPayment());
        paymentContext.executePayment(300.0);

        paymentContext.setPaymentStrategy(new GPayPayment());
        paymentContext.executePayment(500.0);
    }
}

