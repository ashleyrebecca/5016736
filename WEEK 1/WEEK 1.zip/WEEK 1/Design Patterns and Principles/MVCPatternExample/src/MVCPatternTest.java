public class MVCPatternTest {
    public static void main(String[] args) {
        Student model = new Student("Joy", 15, 75.0);
        StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);

        controller.updateView();

        controller.setStudentName("Joy");
        controller.setStudentGrade(95.0);
        controller.updateView();
    }
}