public class StripeGateway {
    public void chargeWithStripe(String paymentMethod, double amount) {
        System.out.println("Charging $" + amount + " using Stripe with " + paymentMethod);
    }
}
