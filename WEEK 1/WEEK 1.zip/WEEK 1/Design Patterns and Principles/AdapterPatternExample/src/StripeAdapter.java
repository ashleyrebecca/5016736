public class StripeAdapter implements PaymentProcessor {
    private StripeGateway stripeGateway;

    public StripeAdapter(StripeGateway stripeGateway) {
        this.stripeGateway = stripeGateway;
    }
    
    public void processPayment(String paymentMethod, double amount) {
        stripeGateway.chargeWithStripe(paymentMethod, amount);
    }
}
