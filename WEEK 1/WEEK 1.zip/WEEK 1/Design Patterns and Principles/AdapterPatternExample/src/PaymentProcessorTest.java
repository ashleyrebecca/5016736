public class PaymentProcessorTest {
    public static void main(String[] args) {
    
        PaymentProcessor payPalAdapter = new PayPalAdapter(new PayPalGateway());
        PaymentProcessor stripeAdapter = new StripeAdapter(new StripeGateway());
        PaymentProcessor bankTransferAdapter = new BankTransferAdapter(new BankTransferGateway());

        payPalAdapter.processPayment("Credit Card", 150.0);
        stripeAdapter.processPayment("Debit Card", 100.0);
        bankTransferAdapter.processPayment("Bank Account", 250.0);
    }
}
