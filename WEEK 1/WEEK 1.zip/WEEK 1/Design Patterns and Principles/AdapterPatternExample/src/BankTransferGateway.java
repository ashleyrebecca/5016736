public class BankTransferGateway {
    public void transferWithBank(String paymentMethod, double amount) {
        System.out.println("Transferring $" + amount + " using Bank Transfer with " + paymentMethod);
    }
}
