public class Main {
    public static void main(String[] args) {
        TaskManagementSystem system = new TaskManagementSystem();

        Task task1 = new Task(1, "Creating Dashboard", "Pending");
        Task task2 = new Task(2, "Creating visuals", "In Progress");
        Task task3 = new Task(3, "Present Project", "Pending");

        system.addTask(task1);
        system.addTask(task2);
        system.addTask(task3);

        System.out.println("All tasks:");
        system.traverseTasks();

        System.out.println("\nSearching for task with ID 2:");
        Task foundTask = system.searchTask(2);
        if (foundTask != null) {
            System.out.println(foundTask);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println("\nDeleting task with ID 2:");
        system.deleteTask(2);

        System.out.println("\nAll tasks after deletion:");
        system.traverseTasks();
    }
}
