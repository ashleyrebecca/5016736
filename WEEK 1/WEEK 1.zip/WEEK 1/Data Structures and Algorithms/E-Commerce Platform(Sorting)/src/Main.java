public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Anna", 350.50),
            new Order("2", "Bob", 200.00),
            new Order("3", "Charles", 250.75),
            new Order("4", "Danny", 400.25),
            new Order("5", "Elsa", 300.00)
        };

        System.out.println("Orders before sorting:");
        for (Order order : orders) {
            System.out.println(order);
        }

        SortingAlgorithms.bubbleSort(orders);
        System.out.println("\nOrders after Bubble Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }
        orders = new Order[]{
            new Order("1", "Anna", 250.50),
            new Order("2", "Bob", 100.00),
            new Order("3", "Charles", 150.75),
            new Order("4", "Danny", 300.25),
            new Order("5", "Elsa", 200.00)
        };

        SortingAlgorithms.quickSort(orders, 0, orders.length - 1);
        System.out.println("\nOrders after Quick Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }
    }
    
}
