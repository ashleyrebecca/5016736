public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        library.addBook(new Book(1, "Harry Potter and the Philosopher's Stone", "J.K. Rowling"));
        library.addBook(new Book(2, "The Hobbit", "J.R.R. Tolkien"));
        library.addBook(new Book(3, "1984", "George Orwell"));

        System.out.println("Linear Search for 'The Hobbit':");
        Book foundBook = library.linearSearchByTitle("The Hobbit");
        if (foundBook != null) {
            System.out.println("Found: " + foundBook);
        } else {
            System.out.println("Book not found.");
        }

        System.out.println("\nBinary Search for '1984':");
        foundBook = library.binarySearchByTitle("1984");
        if (foundBook != null) {
            System.out.println("Found: " + foundBook);
        } else {
            System.out.println("Book not found.");
        }
    }
    
}
