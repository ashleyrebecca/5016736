public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        inventory.addProduct(new Product("P1", "Laptop", 10, 800));
        inventory.addProduct(new Product("P2", "Smartphone", 15, 400));

        System.out.println("Initial Inventory:");
        inventory.displayProducts();

        inventory.updateProduct("P1", 10, 1000);

        System.out.println("Inventory after update:");
        inventory.displayProducts();

        inventory.deleteProduct("P2");

        System.out.println("Inventory after deletion:");
        inventory.displayProducts();
    }
}
