public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(10);

        Employee emp1 = new Employee(1, "Alex", "Manager", 70000);
        Employee emp2 = new Employee(2, "Bobby", "Developer", 60000);
        Employee emp3 = new Employee(3, "Cassy", "Analyst", 50000);

        system.addEmployee(emp1);
        system.addEmployee(emp2);
        system.addEmployee(emp3);

        System.out.println("All employees:");
        system.traverseEmployees();

        System.out.println("\nSearching for employee with ID 2:");
        Employee foundEmployee = system.searchEmployee(2);
        if (foundEmployee != null) {
            System.out.println(foundEmployee);
        } else {
            System.out.println("Employee not found.");
        }

        System.out.println("\nDeleting employee with ID 2:");
        system.deleteEmployee(2);

        System.out.println("\nAll employees after deletion:");
        system.traverseEmployees();
    }
}