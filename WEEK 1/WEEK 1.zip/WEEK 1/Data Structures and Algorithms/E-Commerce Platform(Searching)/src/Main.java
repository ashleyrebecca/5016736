import java.util.Arrays;
public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product("P1", "Laptop", "Electronics"),
            new Product("P2", "Smartphone", "Electronics"),
            new Product("P3", "Macbook", "Electronics"),
            new Product("P4", "Airpods", "Accessories")
        };

        Product foundProduct = SearchAlgorithms.linearSearch(products, "P2");
        System.out.println("Linear Search Found: " + foundProduct+"\n");

        foundProduct = SearchAlgorithms.binarySearch(products, "P2");
        System.out.println("Binary Search Found: " + foundProduct);
    }
}
class Product {
    private String productId;
    private String productName;
    private String category;

    public Product(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getCategory() {
        return category;
    }
    
    public String toString() {
        return "Product{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}
class SearchAlgorithms {
    public static Product linearSearch(Product[] products, String productId) {
        for (Product product : products) {
            if (product.getProductId().equals(productId)) {
                return product;
            }
        }
        return null;
    }

    public static Product binarySearch(Product[] products, String productId) {
        Arrays.sort(products, (a, b) -> a.getProductId().compareTo(b.getProductId()));
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = products[mid].getProductId().compareTo(productId);

            if (cmp == 0) {
                return products[mid];
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
}



