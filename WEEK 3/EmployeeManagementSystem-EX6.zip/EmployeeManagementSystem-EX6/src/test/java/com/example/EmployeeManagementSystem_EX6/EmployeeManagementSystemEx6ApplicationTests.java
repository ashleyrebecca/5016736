package com.example.EmployeeManagementSystem_EX6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemEx6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
