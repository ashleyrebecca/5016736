package com.example.EmployeeManagementSystem_EX6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemEx6Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemEx6Application.class, args);
	}

}
