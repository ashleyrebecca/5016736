package com.example.EmployeeManagementSystem_EX8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemEx8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
