package com.example.EmployeeManagementSystem_EX8.projection;

public interface EmployeeNameProjection {
    String getName();
    String getEmail();
}

