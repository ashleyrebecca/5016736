package com.example.EmployeeManagementSystem_EX8.projection;

public interface DepartmentNameProjection {
    String getName();
}
