package com.example.EmployeeManagementSystem_EX8.repository;
import com.example.EmployeeManagementSystem_EX8.entity.Department;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.EmployeeManagementSystem_EX8.projection.DepartmentNameProjection;
import org.springframework.data.jpa.repository.Query;

@Repository

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    @Query("SELECT d FROM Department d")
    List<DepartmentNameProjection> findAllDepartmentNames();
    Department findByName(String name);
    boolean existsByName(String name);
}
