package com.example.EmployeeManagementSystem_EX5.service;
import com.example.EmployeeManagementSystem_EX5.entity.Department;
import com.example.EmployeeManagementSystem_EX5.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import javax.management.relation.RelationNotFoundException;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    // Create or Update Department
    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }

    // Read all Departments
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    // Read Department by ID
    public Department getDepartmentById(Long id) throws RelationNotFoundException {
        return departmentRepository.findById(id)
            .orElseThrow(() -> new RelationNotFoundException("Department not found with id: " + id));
    }

    // Delete Department by ID
    public void deleteDepartment(Long id) throws RelationNotFoundException {
        Department department = departmentRepository.findById(id)
            .orElseThrow(() -> new RelationNotFoundException("Department not found with id: " + id));
        departmentRepository.delete(department);
    }
}
