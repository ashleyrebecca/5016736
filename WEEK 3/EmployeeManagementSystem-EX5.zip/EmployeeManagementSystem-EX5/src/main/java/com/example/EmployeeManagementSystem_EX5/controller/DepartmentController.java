package com.example.EmployeeManagementSystem_EX5.controller;
import com.example.EmployeeManagementSystem_EX5.entity.Department;
import com.example.EmployeeManagementSystem_EX5.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import javax.management.relation.RelationNotFoundException;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    // Create a new Department
    @PostMapping
    public Department createDepartment(@RequestBody Department department) {
        return departmentService.saveDepartment(department);
    }

    // Get all Departments
    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentService.getAllDepartments();
    }

    // Get Department by ID
    @GetMapping("/{id}")
    public Department getDepartmentById(@PathVariable Long id) throws RelationNotFoundException {
        return departmentService.getDepartmentById(id);
    }

    // Update Department by ID
    @PutMapping("/{id}")
    public Department updateDepartment(@PathVariable Long id, @RequestBody Department departmentDetails) throws RelationNotFoundException {
        Department department = departmentService.getDepartmentById(id);
        department.setName(departmentDetails.getName());
        return departmentService.saveDepartment(department);
    }

    // Delete Department by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDepartment(@PathVariable Long id) throws RelationNotFoundException {
        departmentService.deleteDepartment(id);
        return ResponseEntity.noContent().build();
    }
}

