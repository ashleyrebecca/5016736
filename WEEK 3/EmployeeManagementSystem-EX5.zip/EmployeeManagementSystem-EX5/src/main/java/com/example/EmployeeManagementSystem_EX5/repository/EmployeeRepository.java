package com.example.EmployeeManagementSystem_EX5.repository;
import com.example.EmployeeManagementSystem_EX5.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Custom query using JPQL
    @Query("SELECT e FROM Employee e WHERE e.department.name = :departmentName")
    List<Employee> findEmployeesByDepartmentName(@Param("departmentName") String departmentName);

    // Custom query using native SQL
    @Query(value = "SELECT * FROM employees e WHERE e.email = :email", nativeQuery = true)
    Employee findEmployeeByEmailNative(@Param("email") String email);
}

