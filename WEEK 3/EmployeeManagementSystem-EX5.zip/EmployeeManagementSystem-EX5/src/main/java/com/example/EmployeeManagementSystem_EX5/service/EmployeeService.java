package com.example.EmployeeManagementSystem_EX5.service;
import com.example.EmployeeManagementSystem_EX5.entity.Employee;
import com.example.EmployeeManagementSystem_EX5.repository.EmployeeRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import javax.management.relation.RelationNotFoundException;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;
     @PersistenceContext
    private EntityManager entityManager;

    // Example of a method using EntityManager
    public Employee getEmployeeByEmail(String email) {
        return entityManager.createNamedQuery("Employee.findByEmail", Employee.class)
                            .setParameter("email", email)
                            .getSingleResult();
    }

    // Create or Update Employee
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    // Read all Employees
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // Read Employee by ID
    public Employee getEmployeeById(Long id) throws RelationNotFoundException {
        return employeeRepository.findById(id)
            .orElseThrow(() -> new RelationNotFoundException("Employee not found with id: " + id));
    }

    // Delete Employee by ID
    public void deleteEmployee(Long id) throws RelationNotFoundException {
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new RelationNotFoundException("Employee not found with id: " + id));
        employeeRepository.delete(employee);
    }
}
