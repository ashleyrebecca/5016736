package com.example.EmployeeManagementSystem_EX5.repository;
import com.example.EmployeeManagementSystem_EX5.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    Department findByName(String name);
    boolean existsByName(String name);
}
