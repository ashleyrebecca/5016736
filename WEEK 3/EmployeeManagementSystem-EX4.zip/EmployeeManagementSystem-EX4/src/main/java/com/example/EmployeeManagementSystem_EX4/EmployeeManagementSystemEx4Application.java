package com.example.EmployeeManagementSystem_EX4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemEx4Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemEx4Application.class, args);
	}

}
