package com.example.EmployeeManagementSystem_EX9.repository;
import com.example.EmployeeManagementSystem_EX9.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;

@Repository

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    @Query("SELECT d FROM Department d")
    Department findByName(String name);
    boolean existsByName(String name);
}
