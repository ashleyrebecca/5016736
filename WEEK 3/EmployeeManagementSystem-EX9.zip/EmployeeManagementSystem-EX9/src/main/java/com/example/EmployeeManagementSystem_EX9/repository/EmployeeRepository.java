package com.example.EmployeeManagementSystem_EX9.repository;
import com.example.EmployeeManagementSystem_EX9.entity.Employee;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    @Query("SELECT e FROM Employee e")

    // Find employees by name
    List<Employee> findByName(String name);

    // Find employees by email
    Employee findByEmail(String email);

    // Find employees by department name
    List<Employee> findByDepartment_Name(String departmentName);

    // Find employees by name containing a substring (case insensitive)
    List<Employee> findByNameContainingIgnoreCase(String name);

    // Find employees by name starting with a specific prefix
    List<Employee> findByNameStartingWith(String prefix); 
}