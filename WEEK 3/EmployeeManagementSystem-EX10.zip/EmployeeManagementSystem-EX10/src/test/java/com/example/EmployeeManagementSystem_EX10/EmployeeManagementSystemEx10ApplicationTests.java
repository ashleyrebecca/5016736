package com.example.EmployeeManagementSystem_EX10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemEx10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
