package com.example.EmployeeManagementSystem_EX10.service;

import com.example.EmployeeManagementSystem_EX10.entity.Employee;
import com.example.EmployeeManagementSystem_EX10.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Transactional
    public void saveAllEmployees(List<Employee> employees) {
        for (int i = 0; i < employees.size(); i++) {
            employeeRepository.save(employees.get(i));

            if (i % 50 == 0) { // Flush and clear session after every 50 inserts
                employeeRepository.flush();
                employeeRepository.clear();
            }
        }
    }
}
