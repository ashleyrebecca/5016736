package com.example.EmployeeManagementSystem_EX10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemEx10Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemEx10Application.class, args);
	}

}
