package com.example.EmployeeManagementSystem_EX7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemEx7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
