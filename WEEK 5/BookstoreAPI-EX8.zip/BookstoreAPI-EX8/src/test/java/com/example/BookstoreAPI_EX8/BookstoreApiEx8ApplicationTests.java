package com.example.BookstoreAPI_EX8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
