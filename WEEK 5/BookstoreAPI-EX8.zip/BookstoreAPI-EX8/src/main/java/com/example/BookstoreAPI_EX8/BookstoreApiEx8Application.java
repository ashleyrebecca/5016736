package com.example.BookstoreAPI_EX8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiEx8Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApiEx8Application.class, args);
	}

}
