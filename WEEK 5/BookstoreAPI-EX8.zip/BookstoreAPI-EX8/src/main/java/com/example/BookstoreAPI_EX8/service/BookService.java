package com.example.BookstoreAPI_EX8.service;
import com.example.BookstoreAPI_EX8.dto.BookDTO;
import com.example.BookstoreAPI_EX8.entity.Book;
import org.springframework.stereotype.Service;

@Service
public class BookService {
    
    public BookDTO convertToDto(Book book) {
        BookDTO bookDTO = new BookDTO();
        bookDTO.setId(book.getId());
        bookDTO.setTitle(book.getTitle());
        bookDTO.setAuthor(book.getAuthor());
        bookDTO.setPrice(book.getPrice());
        bookDTO.setIsbn(book.getIsbn());
        return bookDTO;
    }
    
    public Book convertToEntity(BookDTO bookDTO) {
        Book book = new Book();
        book.setId(bookDTO.getId());
        book.setTitle(bookDTO.getTitle());
        book.setAuthor(bookDTO.getAuthor());
        book.setPrice(bookDTO.getPrice());
        book.setIsbn(bookDTO.getIsbn());
        return book;
    }

    public static Book getBookById(Long id) {
        throw new UnsupportedOperationException("Unimplemented method 'getBookById'");
    }
}
