package com.example.BookstoreAPI_EX11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiEx11Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApiEx11Application.class, args);
	}

}
