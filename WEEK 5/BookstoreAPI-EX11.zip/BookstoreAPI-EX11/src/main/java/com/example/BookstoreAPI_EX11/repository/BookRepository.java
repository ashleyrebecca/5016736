package com.example.BookstoreAPI_EX11.repository;
import com.example.BookstoreAPI_EX11.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
}
