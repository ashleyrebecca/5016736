package com.example.BookstoreAPI_EX11.service;
import com.example.BookstoreAPI_EX11.dto.BookDTO;
import com.example.BookstoreAPI_EX11.entity.Book;
import com.example.BookstoreAPI_EX11.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public List<BookDTO> getAllBooks() {
        return bookRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public BookDTO createBook(BookDTO bookDTO) {
        Book book = convertToEntity(bookDTO);
        Book savedBook = bookRepository.save(book);
        return convertToDTO(savedBook);
    }

    // Conversion methods between DTO and Entity
    private BookDTO convertToDTO(Book book) {
        return new BookDTO(book.getId(), book.getTitle(), book.getAuthor(), book.getPrice(), book.getIsbn());
    }

    private Book convertToEntity(BookDTO bookDTO) {
        return new Book();
    }
}