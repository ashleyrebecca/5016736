package com.example.BookstoreAPI_EX11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
