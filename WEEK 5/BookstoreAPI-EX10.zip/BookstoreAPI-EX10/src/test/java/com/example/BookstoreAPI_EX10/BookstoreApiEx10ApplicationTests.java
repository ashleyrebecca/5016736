package com.example.BookstoreAPI_EX10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
