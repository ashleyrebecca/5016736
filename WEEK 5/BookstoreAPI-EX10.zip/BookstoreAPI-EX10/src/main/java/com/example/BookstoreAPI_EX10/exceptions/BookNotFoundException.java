package com.example.BookstoreAPI_EX10.exceptions;
public class BookNotFoundException extends RuntimeException {
    public BookNotFoundException(String message) {
        super(message);
    }
} 
