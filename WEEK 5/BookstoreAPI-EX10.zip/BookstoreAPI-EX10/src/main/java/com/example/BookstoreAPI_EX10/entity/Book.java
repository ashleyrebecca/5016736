package com.example.BookstoreAPI_EX10.entity;
import lombok.Data;
import jakarta.validation.constraints.*;

import jakarta.persistence.*;

@Data
@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Title cannot be null")
    @Size(min = 2, max = 100, message = "Title should be between 2 and 100 characters")
    private String title;

    @NotNull(message = "Author cannot be null")
    @Size(min = 2, max = 100, message = "Author should be between 2 and 100 characters")
    private String author;

    @NotNull(message = "ISBN cannot be null")
    @Size(min = 10, max = 13, message = "ISBN should be between 10 and 13 characters")
    private String isbn;

    @Min(value = 0, message = "Price should not be less than 0")
    private double price;

    @Version
    private Integer version;
}
