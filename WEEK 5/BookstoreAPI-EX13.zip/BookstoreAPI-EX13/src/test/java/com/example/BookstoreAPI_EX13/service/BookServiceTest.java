package com.example.BookstoreAPI_EX13.service;
import com.example.BookstoreAPI_EX13.entity.Book;
import com.example.BookstoreAPI_EX13.repository.BookRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

@SpringBootTest
public class BookServiceTest {

    @Mock
    private BookRepository bookRepository;

    @InjectMocks
    private BookService bookService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllBooks() {
        given(bookRepository.findAll()).willReturn(Collections.singletonList(new Book()));
        assertEquals(1, bookService.getAllBooks().size());
    }

    @Test
    public void testGetBookById() {
        Book book = new Book();
        book.setId(1L);
        given(bookRepository.findById(1L)).willReturn(Optional.of(book));
        assertTrue(bookService.getBookById(1L).isPresent());
    }

    @Test
    public void testAddBook() {
        Book book = new Book();
        given(bookRepository.save(book)).willReturn(book);
        assertEquals(book, bookService.addBook(book));
    }

    @Test
    public void testUpdateBook() {
        Book book = new Book();
        given(bookRepository.save(book)).willReturn(book);
        assertEquals(book, bookService.updateBook(book));
    }

    @Test
    public void testDeleteBook() {
        bookService.deleteBook(1L);
        verify(bookRepository).deleteById(1L);
    }
}

