package com.example.BookstoreAPI_EX13.repository;
import com.example.BookstoreAPI_EX13.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
}
