package com.example.BookstoreAPI_EX13.metrics;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CustomMetrics {

    @Autowired
    public CustomMetrics(MeterRegistry meterRegistry) {
        meterRegistry.counter("custom.metric.counter").increment();
        meterRegistry.gauge("custom.metric.gauge", Math.random());
    }
}