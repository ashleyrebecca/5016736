package com.example.BookstoreAPI_EX13.controllers;

public @interface WebMvcTest {

}
