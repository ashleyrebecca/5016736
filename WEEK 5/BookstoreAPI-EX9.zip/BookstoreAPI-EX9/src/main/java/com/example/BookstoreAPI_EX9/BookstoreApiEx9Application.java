package com.example.BookstoreAPI_EX9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiEx9Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApiEx9Application.class, args);
	}

}
