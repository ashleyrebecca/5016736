package com.example.BookstoreAPI_EX9.exceptions;
public class BookNotFoundException extends RuntimeException {
    public BookNotFoundException(String message) {
        super(message);
    }
}
