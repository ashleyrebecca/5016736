package com.example.BookstoreAPI_EX9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
