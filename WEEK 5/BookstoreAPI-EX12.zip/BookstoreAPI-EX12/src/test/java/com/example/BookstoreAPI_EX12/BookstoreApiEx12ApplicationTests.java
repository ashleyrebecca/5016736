package com.example.BookstoreAPI_EX12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
