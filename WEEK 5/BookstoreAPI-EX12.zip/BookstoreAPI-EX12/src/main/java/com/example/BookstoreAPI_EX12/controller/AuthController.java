package com.example.BookstoreAPI_EX12.controller;

import com.example.BookstoreAPI_EX12.entity.User;
import com.example.BookstoreAPI_EX12.service.CustomUserDetailsService;
import com.example.BookstoreAPI_EX12.security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private JwtUtils jwtUtils;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        String username = user.getUsername();
        String password = user.getPassword();

        var userDetails = userDetailsService.loadUserByUsername(username);
        if (userDetails != null && jwtUtils.passwordEncoder().matches(password, userDetails.getPassword())) {
            String token = jwtUtils.generateToken(username);
            return ResponseEntity.ok(token);
        }
        return ResponseEntity.status(HttpServletResponse.SC_UNAUTHORIZED).body("Invalid credentials");
    }
}

