package com.example.BookstoreAPI_EX12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiEx12Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApiEx12Application.class, args);
	}

}
