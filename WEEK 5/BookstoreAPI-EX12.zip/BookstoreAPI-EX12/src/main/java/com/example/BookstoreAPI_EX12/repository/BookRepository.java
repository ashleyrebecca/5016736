package com.example.BookstoreAPI_EX12.repository;

import com.example.BookstoreAPI_EX12.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
}
