package com.example.BookstoreAPI_EX12.repository;

import com.example.BookstoreAPI_EX12.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
