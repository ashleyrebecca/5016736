package com.example.BookstoreAPI_EX15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiEx15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
