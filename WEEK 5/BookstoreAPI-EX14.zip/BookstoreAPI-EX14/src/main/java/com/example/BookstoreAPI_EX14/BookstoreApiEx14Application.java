package com.example.BookstoreAPI_EX14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiEx14Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApiEx14Application.class, args);
	}

}
