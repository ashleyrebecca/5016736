package com.example.BookstoreAPI_EX14.repository;


import com.example.BookstoreAPI_EX14.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
}
  

