package com.example.controller;


import com.example.BookstoreAPI_EX14.entity.Book;
import com.example.BookstoreAPI_EX14.repository.BookRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;

@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
@ActiveProfiles("test")
public class BookControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BookRepository bookRepository;

    @BeforeEach
    public void setup() {
        bookRepository.deleteAll(); // Clean up the database before each test
    }

    @Test
    public void testGetAllBooks() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/books")
                .contentType("application/json"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    public void testGetBookById() throws Exception {
        Book book = new Book();
        book.setTitle("Test Book");
        book.setAuthor("Author");
        book.setPrice(20.0);
        book.setIsbn("1234567890");
        book = bookRepository.save(book);

        mockMvc.perform(MockMvcRequestBuilders.get("/books/{id}", book.getId())
                .contentType("application/json"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title").value("Test Book"));
    }

    @Test
    public void testAddBook() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/books")
                .contentType("application/json")
                .content("{\"title\":\"New Book\",\"author\":\"Author\",\"price\":15.0,\"isbn\":\"0987654321\"}"))
                .andExpect(MockMvcResultMatchers.status().isCreated());
    }

    @Test
    public void testUpdateBook() throws Exception {
        Book book = new Book();
        book.setTitle("Old Title");
        book.setAuthor("Old Author");
        book.setPrice(10.0);
        book.setIsbn("1234567890");
        book = bookRepository.save(book);

        mockMvc.perform(MockMvcRequestBuilders.put("/books/{id}", book.getId())
                .contentType("application/json")
                .content("{\"title\":\"Updated Title\",\"author\":\"Updated Author\",\"price\":25.0,\"isbn\":\"0987654321\"}"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    public void testDeleteBook() throws Exception {
        Book book = new Book();
        book.setTitle("Delete Me");
        book.setAuthor("Author");
        book.setPrice(10.0);
        book.setIsbn("1234567890");
        book = bookRepository.save(book);

        mockMvc.perform(MockMvcRequestBuilders.delete("/books/{id}", book.getId())
                .contentType("application/json"))
                .andExpect(MockMvcResultMatchers.status().isNoContent());
    }
}

